// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("leak sanitizer"); }
int main(){
  announce();
  return lionss_run_workload("leak-sanitizer");
}
