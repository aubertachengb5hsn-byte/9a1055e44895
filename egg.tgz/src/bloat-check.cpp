// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("bloat check\n", stdout);
  return lionss_run_workload("bloat-check");
}
